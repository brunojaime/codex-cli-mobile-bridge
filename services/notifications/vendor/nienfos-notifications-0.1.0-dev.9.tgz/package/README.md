# Notificaciones compartidas Nienfos

`@nienfos/notifications@0.1.0-dev.3` agrega Firebase Cloud Messaging a apps web con un backend propio. Es independiente de Google login. Contiene el cliente web, inicialización del service worker, registro autenticado de dispositivos, transporte HTTP v1 y outbox persistente D1. No necesita Firebase Auth, Firestore, Analytics ni cambiar la base de datos del producto.

Estado: Gestión web (dev.2) tiene recepción/clic reales confirmados. dev.3 agrega controlador y transporte nativos Android/iOS, preparado en Deseo; credenciales, builds y entrega nativa pendientes. No se activa automáticamente en otras apps.

## Integración de una app

1. Instalar el tarball exacto en `vendor/` y guardar su integridad con el lockfile. Importar desde `@nienfos/notifications`, `/d1`, `/worker`, `/web` y `/sw`. Mantener imports de servidor fuera del bundle web.
2. Ejecutar `nienfos-notifications init --app=mi-app --env=dev --origin=https://mi-app.example --project=mi-proyecto-firebase --out=./config`. Crea configuración pública deshabilitada, no recursos remotos. Repetir por ambiente; no reutilizar credenciales dev en prod.
3. Completar `firebase.appId`, `apiKey`, `messagingSenderId` y `vapidKey` desde la aplicación web Firebase; `nienfos-notifications check --config=./config/notifications.json` valida forma y coherencia pública. No verifica la existencia del proyecto ni la entrega.
4. Incorporar `schema.sql` a una migración aditiva del consumidor. Adaptar `examples/worker.ts` a su sesión, membresía y limitador persistente. Montar sólo POST/DELETE `/api/notifications/devices`; no crear endpoint público de envío.
5. Integrar `examples/service-worker.ts` en el worker existente y compilarlo. Página y SW usan exactamente el mismo nombre Firebase, derivado de app/ambiente/Firebase app ID. Pasar esa inscripción SW a `createWebNotifications`, junto con `accountKey` opaco que identifique cuenta+empresa. Preparar el controlador después del login; activar sólo con clic en «Activar notificaciones». `refresh()` sincroniza únicamente si esa cuenta ya aceptó.
6. Al cerrar sesión, cambiar cuenta/empresa o rotar el ID de sesión, revocar la asociación anterior en servidor antes de invalidar la sesión. `disable()` cancela la inscripción del navegador; `dispose()` sólo quita listeners. Si el usuario cierra otras sesiones, `canDeliver` debe rechazarlas. Mostrar fallo/reintentar si una baja remota no pudo completarse. No reutilizar un controlador entre cuentas.
7. Desde un evento de negocio autorizado, ejecutar `enqueue(recipient, notice)` con evento estable, destinatario derivado de datos del servidor y texto genérico. Ejecutar `drain()` en el scheduled handler/consumidor de cola del producto, y `prune()` diariamente. Configurar el disparador en el deployment existente; importar la función no crea un cron.
8. Validar local, luego un dispositivo de prueba real en dev con permiso explícito. Habilitar la configuración sólo al completar credenciales, migración, SW y prueba. Promoción QA/prod conserva el gate del proyecto.

`createD1Notifications` desde `/worker` compone el backend con una llamada y acepta configuración deshabilitada sin credenciales. `examples/worker.ts` y `examples/web.ts` muestran las llamadas completas. Los hooks de autenticación, autorización y límites son obligatorios: el módulo no adivina las tablas ni roles del producto. Mantener la instancia del transporte cuando el runtime lo permita para aprovechar el cache OAuth. `authenticate` debe devolver sólo sesiones activas, no datos del body. `canDeliver` revalida sesión, membresía y preferencias del destinatario; falla cerrado.

## Credenciales y aislamiento

Cada app/ambiente configura una aplicación Firebase y su proyecto emisor. La configuración web y VAPID pública pueden estar en el frontend. `FIREBASE_SERVICE_ACCOUNT_JSON` es exclusivamente de servidor y se agrega por el panel Secrets o gestor de secretos del consumidor. Nunca JSON de cuenta de servicio en el archivo público, repositorio, captura o informe. No usar el client secret de Google login para FCM.

Para productos independientes, preferir proyectos Firebase separados por producto y ambiente: las credenciales FCM autorizan a nivel de proyecto, no de aplicación web. Varias apps en un proyecto comparten cuotas y autoridad de envío aunque el módulo separe registros; no venderlo como aislamiento fuerte. Un proyecto Firebase permite varias plataformas del mismo producto (web/Android/iOS).

El adaptador de clave usa OAuth2 RS256 con tokens de una hora y scope `firebase.messaging`, cache/coalescencia, timeout y rechazo de redirecciones. Un proveedor de access token de identidad de carga de trabajo puede sustituirlo. Otorgar sólo permisos FCM de envío al proyecto destino; no roles Owner/Editor por comodidad. La implementación de referencia exige coincidencia de proyecto de credencial/destino.

## Semántica de entrega

- Destinatarios ligados a app, ambiente, empresa, cuenta, sesión e instalación. Las rutas públicas no aceptan destinatarios de envío. Registro de FID requiere sesión, Origin y límite persistente; una instalación existente no se transfiere a otra sesión implícitamente.
- FIDs se tratan como identificadores privados: no logs ni URLs. No constituyen prueba de identidad. Para apps con registro hostil o información sensible, agregar prueba de posesión de instalación antes de aceptar inscripciones; este módulo no la implementa. Usar avisos genéricos y revalidar autorización al abrir la app.
- Idempotencia de encolado por evento/instalación, aislada por app/ambiente. Conserva filas hasta siete días después de vencer; no deduplica eventos reenviados después de esa retención. El evento debe crearse una sola vez por cambio de negocio. Si el evento y outbox deben confirmar en una sola transacción, implementar esa transacción en el adaptador del producto.
- Claim atómico, lease 120 segundos, lote máximo 20, concurrencia 4, máximo 6 intentos, TTL máximo 24 horas. Retry-After y backoff con jitter para 429/5xx/fallos de red. No dormir dentro del Worker; persiste `next_at`.
- `accepted` significa aceptado por FCM, **no recibido ni leído**. Un timeout tras aceptación puede producir duplicados; no hay exactly-once. `eventId` y tag permiten agrupar/deduplicar en UI. No usar push como única fuente de verdad.
- `UNREGISTERED` explícito elimina el registro correspondiente. Un 400/403/404 genérico no elimina dispositivos. Un FID rotado cancela trabajos ligados al anterior, evitando enviar a un destino obsoleto.
- Se cancelan trabajos vencidos, sesiones/membresías revocadas o instalaciones dadas de baja. Un envío ya aceptado por FCM puede llegar después de cerrar sesión: el payload no debe contener datos sensibles.
- Registros sin refresh durante 30 días dejan de recibir y se purgan. El contenido/FID de trabajos terminados se borra; quedan estado y referencia mínima durante la retención. Definir retención/aviso de privacidad en el producto.

## Compatibilidad y límites

Web usa los módulos oficiales `@firebase/app 0.16.2` y `@firebase/messaging 0.13.3` (Firebase JS 12.19.0), fijados para usar `register/onRegistered/unregister` y destino `fid` HTTP v1. No mezcla APIs nuevas con tokens legacy. Importar sólo esos módulos evita instalar servicios Firebase ajenos. No hay Analytics automático. Frontend debe compilar módulo SW y conservar soporte offline existente.

Requiere HTTPS, Push API y service workers compatibles; `isSupported()` evita prometerlo en navegadores sin soporte. En iPhone/iPad, validar instalación en pantalla de inicio y permiso según versión/soporte. Android nativo requiere paquete Android y SDK propio; Apple nativo además APNs. No están implementados en esta versión.

El backend usa Web Crypto/fetch/jose y D1; otro proveedor de persistencia implementa `Store`. Capacidad probada funcionalmente, no benchmark de miles de destinatarios. Configurar capacidad/frecuencia de drain y observar edades de cola, errores agregados y aceptaciones sin loguear FIDs o payloads.

## Android/iOS en dev.3

Importar createNativeNotifications desde /native. Puertos: permiso explícito, consentimiento privado por cuenta, getToken/deleteToken/onTokenRefresh FCM, save/revoke Bearer. RN Firebase sirve FCM para ambas plataformas; no pasar tokens APNs ni Expo Push como token FCM. Endpoints con clientMode=native rechazan cookies y requieren Bearer validado por consumidor. Body de registro: installationId, token y platform android/ios.

Usar schema.sql nuevo o upgrade-dev2.sql para consumidores anteriores. La columna legacy fid almacena el destino opaco y platform determina transporte. No actualizar consumidores dev.2 sin migración. Mantener credenciales por app/ambiente. iOS necesita APNs y firma Apple; no está certificado por las pruebas web.
