import { installNotificationWorker } from '@nienfos/notifications/sw';
// Replace this import with your build's PUBLIC configuration (never service-account JSON).
import config from './notifications.json';
if(config.enabled) installNotificationWorker({...config.scope,firebase:config.firebase});
// Bundle into the EXISTING app worker. Preserve caching, offline and update handling.
