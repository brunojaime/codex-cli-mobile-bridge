// Integrate with YOUR application's session/authentication and existing scheduled handler.
// This is a factory, not an unauthenticated standalone Worker.
import { createD1Notifications, type WorkerOptions } from '@nienfos/notifications/worker';
export function notifications(options: WorkerOptions) {
 return createD1Notifications(options);
}
// Supply db, scope, origin, projectId, enabled, serviceAccountJson from env,
// and authenticate/canDeliver/allowRegistration from your app. When disabled,
// no Firebase credentials are needed. A schema migration is required before activation.
// route POST/DELETE /api/notifications/devices -> service.handle(request)
// before session destruction, account switch, tenant switch -> service.revokeSession(principal)
// scheduled (every minute): ctx.waitUntil(service.drain()); daily: service.prune()
// business event, AFTER tenant/role authorization:
// await service.enqueue({userId,tenantId}, {eventId: immutableEventId,
//   title: 'Tenés novedades', body: 'Abrí la aplicación para verlas.', path:'/avisos',
//   expiresAt: Date.now()+3600000});
// A DB transaction spanning your business event/outbox needs a consumer-specific adapter.
