import {createD1Notifications} from '@nienfos/notifications/worker';
import {allowGoogleRequest} from '@nienfos/app-platform/google-app-d1';
import c from './notifications.config.json' with {type:'json'};
import catalog from './notifications.catalog.json' with {type:'json'};
const digest=async value=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)))).map(x=>x.toString(16).padStart(2,'0')).join('');
const token=request=>request.headers.get('cookie')?.split(';').map(x=>x.trim()).find(x=>x.startsWith('__Host-'+c.appId+'-session='))?.split('=')[1]??'';
const principal=async(s,request)=>({userId:s.user_id,tenantId:s.tenant_id,sessionId:await digest(token(request))});
async function canDeliver(env,p){
 const active=await env.DB.prepare("SELECT 1 FROM platform_google_sessions s JOIN platform_members m ON m.tenant_id=s.tenant_id AND m.user_id=s.user_id JOIN notification_preferences n ON n.tenant_id=m.tenant_id AND n.user_id=m.user_id WHERE s.token_hash=? AND s.user_id=? AND s.tenant_id=? AND s.revoked_at IS NULL AND s.expires_at>? AND m.state='active' AND m.version=s.member_version AND n.enabled=1").bind(p.sessionId,p.userId,p.tenantId,new Date().toISOString()).first();
 if(!active)return false;if(!p.eventId)return true;
 // ResourceOwner example: ownership is immutable in this example, no client-selected recipient.
 return !!await env.DB.prepare('SELECT 1 FROM notification_events WHERE id=? AND tenant_id=? AND user_id=? AND expires_at>?').bind(p.eventId,p.tenantId,p.userId,Date.now()).first();
}
function pipeline(env,auth,registrationOnly=false){return createD1Notifications({db:env.DB,scope:{appId:c.appId,environment:c.environment},origin:c.origin,enabled:!registrationOnly&&c.enabled&&env.NOTIFICATIONS_ENABLED==='true',projectId:c.firebase.projectId||'unconfigured',serviceAccountJson:env.FIREBASE_SERVICE_ACCOUNT_JSON,authenticate:async r=>{try{return await principal(await auth.authenticate(r,'profile:read'),r);}catch{return null;}},canDeliver:p=>canDeliver(env,p),allowRegistration:p=>allowGoogleRequest(env.DB,'notifications',p.userId+':'+p.sessionId,Date.now(),20)});}
export async function handleNotifications(request,env,auth){const path=new URL(request.url).pathname;if(!path.startsWith('/api/notifications/'))return null;if(request.method!=='GET'&&request.headers.get('origin')!==c.origin)return new Response(null,{status:403});
 try{const s=await auth.authenticate(request,'profile:read');const p=await principal(s,request);const csrf=await digest(token(request)+':notifications');if(request.method!=='GET'&&request.headers.get('x-csrf-token')!==csrf)return new Response(null,{status:403});const headers={'Cache-Control':'no-store'};
 if(path==='/api/notifications/config'&&request.method==='GET')return Response.json({...c,csrf,accountKey:p.tenantId+':'+p.userId},{headers});
 if(path==='/api/notifications/preferences'&&request.method==='POST'){const body=await request.json();if(typeof body.enabled!=='boolean')return new Response(null,{status:400});await env.DB.prepare('INSERT INTO notification_preferences VALUES(?,?,?) ON CONFLICT(tenant_id,user_id) DO UPDATE SET enabled=excluded.enabled').bind(p.tenantId,p.userId,body.enabled?1:0).run();if(!body.enabled)await pipeline(env,auth,true).revokeSession(p);return Response.json({ok:true},{headers});}
 if(path==='/api/notifications/devices'&&(request.method==='DELETE'||await canDeliver(env,p)))return pipeline(env,auth,request.method==='DELETE').handle(request);
 return new Response(null,{status:403});}catch{return new Response(null,{status:401});}}
/** Server-only example: caller validates command ownership. All statements and intent commit atomically. */
export async function commitNotificationEvent(db,statements,{id,tenantId,userId,resourceId,code},clock=Date.now()){
 const event=catalog.find(e=>e.code===code);if(!event)throw Error('unknown_event');
 const replay=async()=>{const prior=await db.prepare('SELECT tenant_id,user_id,resource_id,code FROM notification_events WHERE id=?').bind(id).first();if(!prior)return false;if(prior.tenant_id!==tenantId||prior.user_id!==userId||prior.resource_id!==resourceId||prior.code!==code)throw Error('event_identity_conflict');return true;};
 if(await replay())return {replayed:true};
 try{await db.batch([db.prepare('INSERT INTO notification_events VALUES(?,?,?,?,?,?,?,0)').bind(id,tenantId,userId,code,resourceId,clock,clock+event.ttlSeconds*1000),...statements]);return {replayed:false};}catch(error){if(await replay())return {replayed:true};throw error;}
}
export async function drainNotifications(env){const n=pipeline(env,null),events=(await env.DB.prepare('SELECT * FROM notification_events WHERE expanded=0 ORDER BY created_at LIMIT 20').all()).results;
 for(const e of events){const policy=catalog.find(p=>p.code===e.code);if(c.enabled&&env.NOTIFICATIONS_ENABLED==='true'&&policy?.enabled&&e.expires_at>Date.now())await n.enqueue({tenantId:e.tenant_id,userId:e.user_id},{eventId:e.id,title:'Tenés novedades',body:'Abrí la aplicación para consultarlas.',path:policy.path,expiresAt:e.expires_at});await env.DB.prepare('UPDATE notification_events SET expanded=1 WHERE id=?').bind(e.id).run();}
 if(env.PUSH_SENDS_ENABLED==='true')await n.drain();await n.prune();}
