import { createWebNotifications } from '@nienfos/notifications/web';
// Call on client after an authenticated login. Use the app's existing service worker registration.
export async function mountNotifications(options:Parameters<typeof createWebNotifications>[0]) {
 const notifications=await createWebNotifications(options);
 if(!notifications)return null; // unsupported browser; keep app usable
 await notifications.refresh(); // silent; only synchronizes an existing explicit opt-in
 return notifications;
}
// Button 'Activar notificaciones': call notifications.enable() directly on click.
// Button 'Desactivar': await notifications.disable(). Show retry on failure.
// Logout: backend MUST revokeSession, including logout-all, expiry and remote revocation handling.
// Unmount: notifications.dispose(). Don't call enable() automatically on login/page load.
// Render onMessage as an in-app notice; notification payloads in background display once via FCM.
