import {createWebNotifications} from '@nienfos/notifications/web';

export async function mountNotifications({button,create=createWebNotifications,request=fetch,worker=()=>navigator.serviceWorker.register('/notifications-sw.js'),permission=()=>Notification.requestPermission(),currentPermission=()=>Notification.permission}={}) {
 if(!button)return;
 let controller,csrf='',state='off',pending=false,retryEnabled,disposed=false,generation=0;
 const seen=new Set(),status=document.createElement('p');
 status.setAttribute('role','status');button.after(status);
 const labels={off:'Activar avisos',unsupported:'Navegador sin soporte',denied:'Permiso denegado',enabling:'Preparando avisos…',enabled:'Desactivar avisos',error:'Reintentar avisos'};
 const change=s=>{if(disposed)return;state=s;button.textContent=labels[s]??labels.error;button.disabled=pending||s==='unsupported'||s==='enabling';button.dataset.active=String(s==='enabled');status.textContent=s==='denied'?'Revisá el permiso en los ajustes del navegador.':s==='error'?'No pudimos guardar el cambio. Podés reintentar.':'';};
 const cleanup=()=>{generation++;controller?.dispose();controller=undefined;};
 const save=async enabled=>{const r=await request('/api/notifications/preferences',{method:'POST',headers:{'Content-Type':'application/json','x-csrf-token':csrf},body:JSON.stringify({enabled})});if(!r.ok)throw Error('preference_unavailable');};
 async function initialize() {
  cleanup();const run=generation,current=()=>!disposed&&run===generation;
  let partial;
  try {
   const response=await request('/api/notifications/config');if(!current())return;
   if(!response.ok)throw Error('configuration_unavailable');
   const c=await response.json();if(!current())return;csrf=c.csrf;
   if(!c.enabled){state='unconfigured';button.textContent='Avisos pendientes de configuración';return;}
   const serviceWorker=await worker();if(!current())return;
   partial=await create({...c,serviceWorker,csrfToken:()=>csrf,endpoint:'/api/notifications/devices',onState:s=>{if(current())change(s);},onMessage:async payload=>{
    if(!current())return;const id=payload.data?.eventId??payload.messageId;
    if(!id||seen.has(id))return;seen.add(id);if(seen.size>256)seen.delete(seen.values().next().value);
    status.textContent='Recibiste una novedad. Abrí la aplicación para consultarla.';
    if(currentPermission()==='granted')try{await serviceWorker.showNotification('Tenés novedades',{body:'Abrí la aplicación para consultarlas.',tag:id,data:{nienfosForeground:true}});}catch{/* Registration remains usable if OS display fails. */}
   }});
   if(!current()){partial?.dispose();return;}
   if(!partial){change('unsupported');return;}
   controller=partial;await controller.refresh();
  } catch {
   // Invalidate callbacks before disposing a partially initialized controller.
   if(current()){cleanup();change('error');}
  }
 }
 const click=async()=>{
  if(pending||disposed)return;
  if(!controller){pending=true;change('enabling');try{await initialize();}finally{pending=false;if(!disposed){button.disabled=['unsupported','unconfigured','enabling'].includes(state);}}return;}
  const enabled=retryEnabled??(state!=='enabled');
  // Request permission synchronously in this click, never during initialization/retry of config.
  pending=true;retryEnabled=enabled;button.disabled=true;
  try{
   if(enabled){if(await permission()!=='granted'){change('denied');retryEnabled=undefined;return;}if(disposed)return;await save(true);if(disposed)return;await controller.enable();}
   else{await save(false);if(disposed)return;await controller.disable();}
   retryEnabled=undefined;
  }catch{change('error');}finally{pending=false;if(!disposed)button.disabled=['unsupported','unconfigured','enabling'].includes(state);}
 };
 // Install once, before any fallible asynchronous initialization.
 button.addEventListener('click',click);
 const lifecycle={get controller(){return controller;},dispose(){if(disposed)return;disposed=true;cleanup();button.removeEventListener('click',click);status.remove();}};
 pending=true;change('enabling');try{await initialize();}finally{pending=false;if(!disposed)button.disabled=['unsupported','unconfigured','enabling'].includes(state);}
 return lifecycle;
}
if(typeof document!=='undefined'&&document.querySelector('#notifications-enable'))void mountNotifications({button:document.querySelector('#notifications-enable')});
