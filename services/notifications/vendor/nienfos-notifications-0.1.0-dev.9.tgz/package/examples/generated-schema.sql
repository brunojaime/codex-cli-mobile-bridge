CREATE TABLE notification_preferences(tenant_id TEXT NOT NULL,user_id TEXT NOT NULL,enabled INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(tenant_id,user_id));
CREATE TABLE notification_events(id TEXT PRIMARY KEY,tenant_id TEXT NOT NULL,user_id TEXT NOT NULL,code TEXT NOT NULL,resource_id TEXT NOT NULL,created_at INTEGER NOT NULL,expires_at INTEGER NOT NULL,expanded INTEGER NOT NULL DEFAULT 0);
CREATE TRIGGER notification_logout AFTER UPDATE OF revoked_at ON platform_google_sessions WHEN NEW.revoked_at IS NOT NULL BEGIN
 DELETE FROM nienfos_push_devices WHERE session_id=NEW.token_hash;
 UPDATE nienfos_push_outbox SET state='cancelled',fid='',title='',body='' WHERE session_id=NEW.token_hash AND state='pending';
END;
