-- Additive: the push schema remains generation 3. Apply both on new consumers.
CREATE TABLE IF NOT EXISTS nienfos_notice_inbox (
 app_id TEXT NOT NULL, environment TEXT NOT NULL,
 tenant_id TEXT NOT NULL, user_id TEXT NOT NULL, event_id TEXT NOT NULL,
 kind TEXT NOT NULL, resource_id TEXT NOT NULL,
 title TEXT NOT NULL, body TEXT NOT NULL, path TEXT NOT NULL,
 created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL,
 read_at INTEGER, cancelled_at INTEGER, expanded_at INTEGER,
 PRIMARY KEY(app_id,environment,tenant_id,user_id,event_id)
);
CREATE INDEX IF NOT EXISTS nienfos_notice_pending ON nienfos_notice_inbox(app_id,environment,expanded_at,created_at);
CREATE INDEX IF NOT EXISTS nienfos_notice_reader ON nienfos_notice_inbox(app_id,environment,tenant_id,user_id,created_at);
CREATE TABLE IF NOT EXISTS nienfos_notice_preferences (
 app_id TEXT NOT NULL, environment TEXT NOT NULL, tenant_id TEXT NOT NULL,
 user_id TEXT NOT NULL, kind TEXT NOT NULL,
 web INTEGER NOT NULL CHECK(web IN (0,1)), android INTEGER NOT NULL CHECK(android IN (0,1)),
 updated_at INTEGER NOT NULL,
 PRIMARY KEY(app_id,environment,tenant_id,user_id,kind)
);
