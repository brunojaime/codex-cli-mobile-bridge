# Notificaciones Nienfos: continuar desde este proyecto

Leer `notifications.consumer.json`, `notifications.capabilities.json` y
`notifications.catalog.json` antes de implementar avisos. Son el contrato local
de adopción; no asumir activación por la presencia de un paquete o token.

La base compartida es `@nienfos/notifications`. Reutilizar sus exports públicos
y su versión exacta en vendor/lockfile. El proyecto implementa sus eventos,
destinatarios, sesión, autorización por recurso, navegación y presentación.
No copiar el motor de RD, duplicar la cola ni trasladar sus roles a otra app.

## Comandos

`nienfos-notifications check-consumer --manifest=notifications.consumer.json`
comprueba estructura y artefacto local; no accede a proveedores ni certifica
recepción. `check-project` conserva el contrato del generador web v1. Son
comprobaciones complementarias, no un reemplazo de las pruebas del consumidor.

Para una app existente, instalar primero el tarball exacto y ejecutar
`nienfos-notifications adopt --app=PRODUCTO --origin=ORIGEN_HTTPS --out=. --artifact=vendor/ARTEFACTO.tgz --android-package=PAQUETE`.
El comando crea documentación y manifiestos deshabilitados; falla ante conflictos.
Después completar rutas de integración, catálogo y configuración verificable.

## Reglas obligatorias

- Un proyecto Firebase por producto/ambiente; web y Android del mismo ambiente
  lo comparten. Gestión opera el registro/provisión; el backend del consumidor
  conserva datos y autoridad. Secretos de envío sólo en servidor.
- Consultar las capacidades y el registro canónico antes de pedir claves o
  crear recursos. En la instalación Nienfos: registro
  `nienfos-gestion/infra/mobile/firebase-projects.json`; operadores
  `firebase-provision-dev.mjs PRODUCT --apply-dev [web]` y
  `firebase-sender-dev.mjs PRODUCT --apply-dev`. Requieren manifiesto explícito
  y autorización vigente. Otro entorno de ejecución debe instalar su operador;
  la app no depende de rutas absolutas de esta máquina.
- Aviso, entrega y lectura son entidades diferentes. La lectura se comparte
  por cuenta/empresa entre web y Android. El permiso del sistema no reemplaza
  las preferencias ni la autorización de la app.
- Persistir intención de aviso en la misma transacción que el cambio de negocio.
  D1 usa `noticeStatements` dentro de `db.batch`; otras bases implementan
  `CenterStore`/`Store` y su commit transaccional. No llamar al proveedor desde
  la transacción ni enviar después de un commit sin intención durable.
- El consumidor deriva destinatarios en servidor y revalida recursos/sesiones
  al leer, al despachar y al abrir el destino. Nunca aceptar destinatarios del
  navegador. Payload genérico sin datos sensibles. Catálogo explícito por evento.
- `/web` usa FID; `/native` usa token FCM con plataforma. No usar tokens Expo/APNs.
  Web mantiene Origin/CSRF, SW existente y un único listener por sesión.
  Android necesita su SDK, permiso, canal `updates`, secure storage, rotación,
  foreground y clic con destinos permitidos. No pedir permiso automáticamente.
- Revocar antes de logout/cambio de cuenta; disparadores de persistencia cubren
  invalidaciones externas. Una entrega aceptada podría llegar después del logout.
- Preferencias apagadas o lectura previa cancelan el despacho pendiente. El
  inbox se conserva 90 días; push usa su retención propia. Programar expand,
  drain y prune; el ejemplo no instala un cron remoto.
- Tutoriales conserva su registro/lecturas centrales. Integrarlos mediante su
  contrato y audiencia, sin almacenar un segundo contador de tutoriales.

## Cierre y mantenimiento

Registrar versión deseada/instalada/validada, estado por ambiente, IDs reales,
huellas, migraciones, scheduler y evidencia. Validar aislamiento, transacciones,
preferencias, logout, rutas y recepción foreground/background/clic. Separar
preparado, configurado, desplegado, aceptado por Firebase y recibido en dispositivo.
Un `doctor` sin prueba física no puede declarar el último estado.

Cada feature nueva actualiza catálogo/casos y pasa el mantenimiento de release-core
del consumidor. Actualizaciones del paquete son explícitas; no modificar un
tarball publicado ni actualizar otros productos por arrastre. Promoción QA/prod
mantiene la autorización del proyecto. Nada de esto habilita email/WhatsApp.

## Identidad visual de avisos web (dev.9)

`createD1Notifications` y `createFcmTransport` aceptan `webPushBranding: {icon: '/brand/notification-icon.png', badge: '/brand/notification-badge.png'}`. Son recursos públicos del propio origen; se rechazan URLs externas. El consumidor define su logo y una insignia monocromática transparente legible a 24 px. En primer plano, pasar los mismos recursos a `registration.showNotification`. Firebase conserva el único display de segundo plano. No cambia el esquema ni los avisos nativos. Chrome/Android conservan el control de la identificación del navegador y la presentación final. La disponibilidad de imágenes y las pruebas de payload no acreditan su aspecto en un teléfono físico.
