-- Apply through the consumer's reviewed migration; isolated namespace per app/environment.
CREATE TABLE IF NOT EXISTS nienfos_push_devices (
 app_id TEXT NOT NULL, environment TEXT NOT NULL CHECK(environment IN ('dev','qa','prod')),
 installation_id TEXT NOT NULL, fid TEXT NOT NULL,
 platform TEXT NOT NULL DEFAULT 'web' CHECK(platform IN ('web','android','ios')),
 user_id TEXT NOT NULL, tenant_id TEXT NOT NULL, session_id TEXT NOT NULL,
 updated_at INTEGER NOT NULL,
 PRIMARY KEY(app_id,environment,installation_id),
 UNIQUE(app_id,environment,fid)
);
CREATE INDEX IF NOT EXISTS nienfos_push_recipient ON nienfos_push_devices(app_id,environment,tenant_id,user_id,updated_at);
CREATE TABLE IF NOT EXISTS nienfos_push_outbox (
 id TEXT PRIMARY KEY, app_id TEXT NOT NULL, environment TEXT NOT NULL,
 installation_id TEXT NOT NULL, fid TEXT NOT NULL,
 platform TEXT NOT NULL DEFAULT 'web' CHECK(platform IN ('web','android','ios')),
 user_id TEXT NOT NULL, tenant_id TEXT NOT NULL, session_id TEXT NOT NULL,
 event_id TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL, path TEXT NOT NULL,
 expires_at INTEGER NOT NULL, created_at INTEGER NOT NULL,
 state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','accepted','failed','cancelled')),
 attempt INTEGER NOT NULL DEFAULT 0, next_at INTEGER NOT NULL,
 lease TEXT, lease_until INTEGER NOT NULL DEFAULT 0, last_code TEXT,
 UNIQUE(app_id,environment,installation_id,event_id)
);
CREATE INDEX IF NOT EXISTS nienfos_push_due ON nienfos_push_outbox(app_id,environment,state,next_at,lease_until);
