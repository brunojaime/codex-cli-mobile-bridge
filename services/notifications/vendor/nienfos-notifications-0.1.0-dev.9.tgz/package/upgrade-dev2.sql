-- Existing dev.2 consumers must apply before upgrading; do not apply to fresh schema.sql.
ALTER TABLE nienfos_push_devices ADD COLUMN platform TEXT NOT NULL DEFAULT 'web' CHECK(platform IN ('web','android','ios'));
ALTER TABLE nienfos_push_outbox ADD COLUMN platform TEXT NOT NULL DEFAULT 'web' CHECK(platform IN ('web','android','ios'));
